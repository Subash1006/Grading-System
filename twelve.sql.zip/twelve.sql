-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 29, 2024 at 12:48 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `twelve`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `firstname`, `lastname`, `username`, `password`, `picture`, `usertype`) VALUES
(1, 'UNOM', 'GUINDY', 'UNOMGUINDY', 'UNOM@GUINDY', 'admin_avatar.png', 'ADMIN'),
(2, 'UNOM', 'MSC_IT', 'MSC_IT_2022', '2-MSC-IT', 'admin_avatar.png', 'USER'),
(6, 'yasmin', 'riyas', 'aaaa', 'abcd', '01f.jpg', 'USER');

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE IF NOT EXISTS `records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_number` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `picture` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `caste` varchar(50) NOT NULL,
  `batch` int(20) NOT NULL,
  `semester1` int(5) NOT NULL,
  `semester2` int(5) NOT NULL,
  `semester3` int(5) NOT NULL,
  `semester4` int(5) NOT NULL,
  `semester5` int(5) NOT NULL,
  `semester6` int(5) NOT NULL,
  `credit1` int(2) NOT NULL,
  `credit2` int(11) NOT NULL,
  `credit3` int(11) NOT NULL,
  `credit4` int(11) NOT NULL,
  `credit5` int(11) NOT NULL,
  `credit6` int(11) NOT NULL,
  `credits` int(22) NOT NULL,
  `semtotal` decimal(10,3) NOT NULL,
  `entrance` int(10) NOT NULL,
  `total` int(5) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`id`, `teacher_number`, `firstname`, `lastname`, `picture`, `gender`, `religion`, `caste`, `batch`, `semester1`, `semester2`, `semester3`, `semester4`, `semester5`, `semester6`, `credit1`, `credit2`, `credit3`, `credit4`, `credit5`, `credit6`, `credits`, `semtotal`, `entrance`, `total`, `remarks`) VALUES
(5, 2, 'SUBASH', 'K', 'elementary_school.png', 'MALE', 'HINDU', 'BC', 2022, 7, 8, 8, 6, 8, 8, 23, 21, 19, 17, 18, 24, 0, '0.000', 40, 0, '0'),
(16, 2, 'SHANKAR', 'A', 'elementary_school.png', 'MALE', 'HINDU', 'SC', 2022, 6, 7, 8, 9, 7, 8, 17, 16, 12, 13, 11, 19, 0, '0.000', 22, 0, '0'),
(18, 2, 'RAVI', 'S', 'elementary_school.png', 'MALE', 'HINDU', 'BC', 2017, 4, 2, 4, 5, 3, 3, 17, 14, 14, 16, 24, 12, 0, '0.000', 14, 0, '0'),
(19, 2, 'SURENDAR', 'K', '7qMiwNx.jpg', 'MALE', 'HINDU', 'BC', 2022, 9, 9, 9, 8, 7, 9, 18, 19, 19, 18, 19, 24, 0, '0.000', 30, 0, '0'),
(20, 2, 'KUMARAN', 'T', 'admin_avatar.png', 'MALE', 'HINDU', 'BC', 2022, 8, 9, 9, 8, 7, 9, 18, 19, 24, 18, 22, 24, 0, '0.000', 40, 0, '0'),
(21, 2, 'THOSHITH', 'F', 'elementary_school.png', 'MALE', 'CHRISTIAN', 'BC', 2022, 8, 7, 8, 9, 8, 6, 16, 16, 16, 24, 22, 17, 0, '0.000', 38, 0, '0'),
(22, 2, 'VAISHNAVI', 'MANNAVA', 'girl.png', 'FEMALE', 'HINDU', 'BC', 2022, 7, 8, 6, 8, 7, 9, 17, 18, 14, 18, 16, 24, 0, '0.000', 35, 0, '0'),
(24, 2, 'RAJESH', 'H', 'elementary_school.png', 'MALE', 'HINDU', 'BC', 2023, 6, 8, 7, 7, 7, 8, 14, 12, 14, 13, 14, 12, 0, '0.000', 49, 0, '0'),
(25, 2, 'VARISU', 'VIJAY', '7qMiwNx.jpg', 'MALE', 'CHRISTIAN', 'MBC', 1993, 89, 89, 88, 67, 77, 99, 9, 17, 15, 14, 12, 19, 0, '0.000', 32, 0, '0');
